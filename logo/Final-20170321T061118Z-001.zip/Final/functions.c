#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

bool z = false,n = false,o = false;
char t[16];
int r[12] = {0},ic = 0,cc = 0,sp = 0,chg = 1,Mcheck, bnum ;

void resetf(){
	z = false;
}

int MOV(int x, int y){
	x = y;
	return x;
}

void CMP(int x, int y){
    if ((x - y) == 0) {
        z = true;
        n = false;
    } else if ((x - y) < 0) {
    n = true;
    z = false;
    o = false;
    }
	else {
		n = false;
		z = false;
	}
}

int ADD(int x,int y) {
	x=x+y;
	if(x==0)
		z = false;
	if (x>31)
		o = true;
		n = false;
	return x;
}

int SUB(int x ,int y){
	x=(x-y);
	if(x<0) 
		n = true;
	if(x==0)
		z = true;
    	o = false;
	return x;		
}

int DIV(int x,int y){
	if(y==0)
		printf("BAD INSTRUCTION!");
	if(x==0);
		z = true;
    o = false;
	x = x / y;
	return x;
}

int MUL(int x,int y){
	x=x*y;
	if(x==0)
		z = true;
	if(x<0)
		n = true;
	if(x>31)
		o = true;
	return x;
}

void HLT() {
	printf("\t\t|\t\t\t\t\t\t\t\t|");
	printf("\n+------------------+--------------------+---+---+---+----+----+-----+-----------------------------------+\n");	
	printf("\nProgram Terminated!\n\n\n");
	exit(0);
}

void MOVU() {
	if (cc >= 25) {
//		printf(" Not Valid as reached end point\n");
		printf("\n Reached End Point \n\n\n");
		exit(0);
	} else {
		cc = cc + 1;
//		printf(" ROBOVAC Moves up.\n");
		Mcheck = 1;
	}
}

void MOVR() {
	if (cc >= 21) {
		printf(" Not Valid as reached end point\n");
		exit(0);
	} else {
		cc = cc + 5;
		printf(" ROBOVAC Moves right.\n");
		Mcheck = 0;
	}
}

void MOVD(){
	if(cc==1)
		printf(" Invalid Move !");
	else
	{
		cc = cc-1;
		printf(" ROBOVAC Moves Down.\n");
	}
	if (cc==25) printf(" Not Valid as reached end point"); exit(0);
}

void SLG(){
	printf(" App Update: Log Recieved.");
}

void SFC(){
	printf(" ROBOVAC Working on Self Clean Mode.");
}

int DIMD(){
    int x = 10;
    return x;
}
 
int GETD(){
    int x = 2;
    return x;
}

int SUP(int x, int y){	
   x=y;
   return x;
}

int CLT(int x ){
    return x = rand()%26;
}

int TOT(int x ){
    return x = rand()%26;
}

int GST(int x ){
    return x = 1;
}

int TYM(int x ){
    return x = rand()%2;
}

int CGL(){
	int x = rand()%10 ;
    return x;
}

void RTM(){
    if(Mcheck == 1 )
    cc = cc-1;
    if(Mcheck == 0 )
    cc = cc-5 ;
}

int GCC(){
    cc = rand()%25;
}

int  SETP(int x){
    return (sp + x)%10;
}

int ODET(int x){
    x = rand()%2; 
    return x;
}

void CLN(int x, int y){
    if(y==1)
        printf("Cleaning on progress!"); 
    else
        printf("No need to Clean!");
}